﻿using System;
using System.Collections.Generic;
using System.IO;

namespace BubbleSort
{
    class Program
    {
        static void Main(string[] args)
        {
            File file = new File();
            file.startProgram();

        }
    }
}
